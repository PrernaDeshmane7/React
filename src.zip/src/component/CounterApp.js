import React, { useState } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';

const CounterApp = () => {
  const [count, setCount] = useState(0);

  const increment = () => setCount(count + 1);
  const decrement = () => setCount(count - 1);
  const reset = () => setCount(0);

  return (
    <div className="d-flex flex-column align-items-center justify-content-center min-vh-100 bg-light">
      <div className="card p-4 shadow-lg text-center">
        <h1 className="mb-3">Counter App</h1>
        <p className="h4 mb-3">Count: {count}</p>
        <div className="btn-group" role="group">
          <button onClick={increment} className="btn btn-success">Increment</button>
          <button onClick={decrement} className="btn btn-danger">Decrement</button>
          <button onClick={reset} className="btn btn-secondary">Reset</button>
        </div>
      </div>
    </div>
  );
};

export default CounterApp;
