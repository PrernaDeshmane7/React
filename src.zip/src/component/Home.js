export default function Home() {
    return <h1 className="text-xl">Welcome to the Home Page</h1>;
  }